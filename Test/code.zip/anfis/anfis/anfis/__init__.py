import anfis
from membership import membershipfunction
from membership import mfDerivs